# 使用步骤
- 1、在/frontend 文件夹下打开cmd
- 2、给前端文件配置一个python-server的服务器，示例：\
python -m http.server 5500\
意思是在端口5500上部署了该http服务器，用来和后端通信
- 3、打开网页，输入http://127.0.0.1:5500，就可以看到我的这个页面了
- 4、打开/backend/chatBotService.py，运行后端服务器
- 5、可以愉快的在前端页面输入啦